INSERT INTO users (email, password, role)
VALUES(?, ?, ?)