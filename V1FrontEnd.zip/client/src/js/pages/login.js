import { UI } from "../../lang/en/user.js";
import { $root, SERVER_BASE_URL, HTML } from "../constants.js";
import { WindowManager } from "../managers/windowManager.js";

const PAGE_TITLE = "Login";
const LOGIN_USER_URL = `${SERVER_BASE_URL}/login_user`;

class FormData {
  constructor(email, password) {
    this.email = email;
    this.password = password;
  }
}

class LogIn {
  constructor() {
    // Create a form
    const form = $(HTML.ELEMENTS.FORM).attr("id", "sign-up-forum");
    const pageTitle = $(HTML.ELEMENTS.H1).text(PAGE_TITLE);

    const emailInput = $(HTML.ELEMENTS.INPUT).attr({
      type: HTML.TYPES.EMAIL,
      name: HTML.NAMES.EMAIL,
      placeholder: HTML.PLACEHOLDERS.EMAIL,
      required: true,
    });

    const passwordInput = $(HTML.ELEMENTS.INPUT).attr({
      type: HTML.TYPES.PASSWORD,
      name: HTML.NAMES.PASSWORD,
      placeholder: HTML.PLACEHOLDERS.PASSWORD,
      required: true,
    });

    // Create submit button
    const logInButton = $(HTML.ELEMENTS.BUTTON)
      .attr({ type: HTML.TYPES.SUBMIT })
      .text(UI.TEXT.LOGIN_BUTTON);

    // Append all inputs and button to form
    form.append(emailInput, passwordInput, logInButton);

    // Handle submit - send credentials to server and store access token
    form.on(HTML.EVENTS.SUBMIT, async function (e) {
      e.preventDefault(); // prevent page reload

      form.text("Redirecting...");
      const formData = new FormData(emailInput.val(), passwordInput.val());
      console.log(formData);

      const request = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      };

      try {
        const response = await fetch(LOGIN_USER_URL, request);
        const data = await response.json();

        if (!response.ok) {
          // show simple alert for errors (could be improved to render in DOM)
          console.log(data.error || "Login failed");
          return;
        }

        const token = data.accessToken;

        if (token) {
          // store token for use on subsequent requests
          localStorage.setItem("accessToken", token);
          console.log("Login successful");
          // Optionally redirect or refresh the app state
          WindowManager.indexPage();
        } else {
          console.log("Login succeeded but no token was returned");
        }
      } catch (err) {
        console.error("Login error", err);
      }
    });

    // Add the form to the root
    $root.append(pageTitle, form);
  }
}

new LogIn();
