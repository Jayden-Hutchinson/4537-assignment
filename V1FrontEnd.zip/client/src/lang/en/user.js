export const UI = {
  TEXT: {
    SIGNUP_BUTTON: "Sign Up",
    LOGIN_BUTTON: "Log In",
    SUBMIT_BUTTON: "Submit",
    LOGOUT_BUTTON: "Logout",
  },
};
